To run the script locally use the q1_local.py
	- python q1_local.py

To run the script across hypervisors use the q1_across_hypervisors.py
	- paramiko package needs to be installed using 'pip install paramiko'
	- For this to execute sucessfully the tls certificates need to installed on 
	  both the hypervisor and the host, the directory to add the certificates is /etc/pki/CA/ in the hypervisor













