#!/bin/bash

rm *.csv
